## Terra Pizza (Game)
### Created by Duha Hassan

To run the game:
- Start the program `TerraPizzaGame.exe`

To exit the game:
- Click on the gear icon at the bottom right of the screen
- Then click on the Quit Game button

Happy pizza making!